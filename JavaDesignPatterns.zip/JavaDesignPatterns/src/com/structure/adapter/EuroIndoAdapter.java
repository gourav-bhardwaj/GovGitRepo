package com.structure.adapter;

import java.util.Arrays;

public class EuroIndoAdapter implements IEuroSocket {
   
	private static final int EURO_SOCKET_VOLT = 80;
	private static final int EURO_SOCKET_AMPS = 3;
	private IIndSocket socket;
	
	public EuroIndoAdapter(IIndSocket socket) {
		this.socket = socket;
	}

	@Override
	public String socketBuilder() {
		return socket.getSocketCompany();
	}

	@Override
	public int socketVolt() {
		int measureVolt = (socket.getWatt()/socketAmps());
		return (measureVolt > EURO_SOCKET_VOLT) ? EURO_SOCKET_VOLT : measureVolt;
	}

	@Override
	public int socketAmps() {
		return EURO_SOCKET_AMPS;
	}

	@Override
	public EuroPlug[] plugInSupport() {
		return EuroPlug.values();
	}

	@Override
	public String toString() {
		return "EuroIndoAdapter [socketBuilder()=" + socketBuilder() + ", socketVolt()=" + socketVolt()
				+ ", socketAmps()=" + socketAmps() + ", plugInSupport()=" + Arrays.toString(plugInSupport()) + "]";
	}
	
	
}
