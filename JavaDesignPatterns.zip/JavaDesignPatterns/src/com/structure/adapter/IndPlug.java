package com.structure.adapter;

public enum IndPlug {
	TYPE_C, TYPE_D;
}
