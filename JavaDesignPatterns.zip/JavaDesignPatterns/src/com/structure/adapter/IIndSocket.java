package com.structure.adapter;

public interface IIndSocket {
	String getSocketCompany();
	
	int getWatt();
	
	IndPlug[] getPlugInSupport();
}
