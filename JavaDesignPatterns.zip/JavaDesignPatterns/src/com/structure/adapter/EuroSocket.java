package com.structure.adapter;

import java.util.Arrays;

public class EuroSocket implements IEuroSocket {

	@Override
	public String socketBuilder() {
		return "Euro Electronic Solution Pvt. Ltd.";
	}

	@Override
	public int socketVolt() {
		return 80;
	}

	@Override
	public int socketAmps() {
		return 3;
	}

	@Override
	public EuroPlug[] plugInSupport() {
		return EuroPlug.values();
	}

	@Override
	public String toString() {
		return "EuroSocket [socketBuilder()=" + socketBuilder() + ", socketVolt()=" + socketVolt() + ", socketAmps()="
				+ socketAmps() + ", plugInSupport()=" + Arrays.toString(plugInSupport()) + "]";
	}
	

}
