package com.structure.adapter;

import java.util.Arrays;

public class IndSocket implements IIndSocket {

	@Override
	public String getSocketCompany() {
		return "Indian Socket Production Solution";
	}

	@Override
	public int getWatt() {
		return 150;
	}

	@Override
	public IndPlug[] getPlugInSupport() {
		return IndPlug.values();
	}

	@Override
	public String toString() {
		return "IndSocket [Company()=" + getSocketCompany() + ", Watt()=" + getWatt()
				+ ", PlugInSupport()=" + Arrays.toString(getPlugInSupport()) + "]";
	}
	
}
