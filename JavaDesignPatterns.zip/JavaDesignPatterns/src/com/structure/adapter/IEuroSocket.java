package com.structure.adapter;

public interface IEuroSocket {
	
	String socketBuilder();
	
	int socketVolt();
	
	int socketAmps();
	
	EuroPlug[] plugInSupport();

}
