package com.structure.adapter;

public enum EuroPlug {
	TYPE_G, TYPE_C, TYPE_I;
}
