package com.structure.proxy;

public enum Gender {
	Male, Female;
}
