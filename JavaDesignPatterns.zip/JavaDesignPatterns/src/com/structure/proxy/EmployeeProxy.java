package com.structure.proxy;

import java.util.Objects;

public class EmployeeProxy extends Employee {

	private EmployeeData data;
	
	public EmployeeProxy(EmployeeData data, int id) {
		this.data = data;
		this.setId(id);
	}
	
	@Override
	public int getId() {
		return super.getId();
	}
	
	@Override
	public String getName() {
		if (Objects.isNull(super.getName())) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			for(Employee e : data.getList()) {
				if (e.getId() == super.getId()) {
					super.setName(e.getName());
					super.setGender(e.getGender());
					super.setSalary(e.getSalary());
				}
			}
		}
		return super.getName();
	}
	
	@Override
	public Gender getGender() {
		if (Objects.isNull(super.getGender())) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			for(Employee e : data.getList()) {
				if (e.getId() == super.getId()) {
					super.setName(e.getName());
					super.setGender(e.getGender());
					super.setSalary(e.getSalary());
				}
			}
		}
		return super.getGender();
	}
	
	@Override
	public float getSalary() {
		if (super.getSalary() == 0.0f) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			for(Employee e : data.getList()) {
				if (e.getId() == super.getId()) {
					super.setName(e.getName());
					super.setGender(e.getGender());
					super.setSalary(e.getSalary());
				}
			}
		}
		return super.getSalary();
	}

}
