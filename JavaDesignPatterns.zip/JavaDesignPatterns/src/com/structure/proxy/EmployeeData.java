package com.structure.proxy;

import java.util.ArrayList;
import java.util.List;

public class EmployeeData {

	private List<Employee> list;
	
	public EmployeeData() {
		list = new ArrayList<>();
	}
	
	public void add(Employee emp) {
		list.add(emp);
	}
	
	public Employee get(int id) {
		return new EmployeeProxy(this, 101);
	}

	public List<Employee> getList() {
		return list;
	}
	
}
