package com.structure.decorator;

public interface FileConstants {

	String FILE_PATH = "E:\\yoyo";
	String FILE_PREFIX = "decorator";
	String FILE_EXT = ".txt";
	
}
