package com.structure.decorator;

import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class FileDataSource implements IFileDataSource {

	@Override
	public void writeData(String text) {
		StringBuilder builder = new StringBuilder();
		builder.append(FileConstants.FILE_PATH)
		.append(File.separatorChar).append(FileConstants.FILE_PREFIX)
		.append(UUID.randomUUID()).append(FileConstants.FILE_EXT);
		try(FileWriter writer = new FileWriter(new File(builder.toString()))){
			writer.write(text);
			writer.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<String> readData() {
		List<String> data = new ArrayList<>();
		File path = new File(FileConstants.FILE_PATH);
		if (path.exists() && path.isDirectory()) {
			try {
				FileFilter fileFilter = new FileFilter() {
					@Override
					public boolean accept(File file) {
						if (file.getName().startsWith(FileConstants.FILE_PREFIX)) {
							return true;
						}
						return false;
					}
				};
				
				File[] files = path.listFiles(fileFilter);
				if (files.length > 0) {
					for(File file : files) {
						StringBuilder builder = new StringBuilder();
						char[] chars = new char[1024];
						FileReader fileReader = new FileReader(file);
						while(fileReader.read(chars) > -1) {
							builder.append(chars);
						}
						data.add(builder.toString());
						fileReader.close();
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return data;
	}

}
