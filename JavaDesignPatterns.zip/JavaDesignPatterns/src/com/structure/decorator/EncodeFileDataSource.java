package com.structure.decorator;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class EncodeFileDataSource extends FileDataSource {

	private FileDataSource fileData;
	
	public EncodeFileDataSource(FileDataSource fileData) {
		this.fileData = fileData;
	}
	
	
	@Override
	public void writeData(String text) {
		String encoded = null;
		try {
			encoded = Base64.getEncoder().encodeToString(text.getBytes());
			fileData.writeData(encoded);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<String> readData() {
		List<String> arr = new ArrayList<>();
		try {
			for(String str : fileData.readData()) {
				byte[] bytes = Base64.getDecoder().decode(str.trim());
				String ss = new String(bytes);
				System.out.println(ss);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return arr;
	}

}
