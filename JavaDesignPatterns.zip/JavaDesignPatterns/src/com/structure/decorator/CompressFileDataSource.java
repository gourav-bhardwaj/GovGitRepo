package com.structure.decorator;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

public class CompressFileDataSource extends FileDataSource {

	@Override
	public void writeData(String text) {
		if(Objects.nonNull(text)) {
			StringBuilder builder = new StringBuilder();
			builder.append(FileConstants.FILE_PATH).append(File.separatorChar).append(FileConstants.FILE_PREFIX)
			.append(UUID.randomUUID()).append(FileConstants.FILE_EXT);
			try (FileOutputStream fos = new FileOutputStream(new File(builder.toString()));
					DeflaterOutputStream dos = new DeflaterOutputStream(fos)) {
				dos.write(text.getBytes());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public List<String> readData() {
		List<String> list = new ArrayList<>();
		try {
			File path = new File(FileConstants.FILE_PATH);
			FileFilter filter = file -> {
				return file.getName().startsWith(FileConstants.FILE_PREFIX);
			};
			for (File file : path.listFiles(filter)) {
				byte[] bytes = new byte[(int) file.length()];
				InflaterInputStream iis = new InflaterInputStream(new FileInputStream(file));
				iis.read(bytes);
				list.add(new String(bytes));
				iis.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
