package com.structure.decorator;

import java.util.List;

public interface IFileDataSource {

	void writeData(String text);
	
	List<String> readData();
	
}
