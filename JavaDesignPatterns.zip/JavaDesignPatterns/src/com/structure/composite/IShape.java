package com.structure.composite;

public interface IShape {

	String shapeType();
	
	void drawing();
	
}
