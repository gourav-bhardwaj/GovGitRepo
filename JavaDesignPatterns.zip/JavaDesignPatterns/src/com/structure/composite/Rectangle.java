package com.structure.composite;

public class Rectangle implements IShape {

	@Override
	public String shapeType() {
		return "Rectangle";
	}

	@Override
	public void drawing() {
		System.out.println(shapeType()+"draw");
	}

}
