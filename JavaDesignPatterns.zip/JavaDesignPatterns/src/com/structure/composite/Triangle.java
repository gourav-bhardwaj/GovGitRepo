package com.structure.composite;

public class Triangle implements IShape {

	@Override
	public String shapeType() {
		return "Triangle";
	}

	@Override
	public void drawing() {
		System.out.println(shapeType()+"draw");
	}

}
