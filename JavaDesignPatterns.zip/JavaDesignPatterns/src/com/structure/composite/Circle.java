package com.structure.composite;

public class Circle implements IShape {

	@Override
	public String shapeType() {
		return "Circle";
	}

	@Override
	public void drawing() {
		System.out.println(shapeType()+"draw");
	}

}
