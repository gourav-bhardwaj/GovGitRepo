package com.structure.composite;

public class Square implements IShape {

	@Override
	public String shapeType() {
		return "Square";
	}

	@Override
	public void drawing() {
		System.out.println(shapeType()+"draw");
	}

}
