package com.structure.composite;

import java.util.ArrayList;
import java.util.List;

public class Composite implements IShape {

	List<IShape> shapes = new ArrayList<>();

	@Override
	public String shapeType() {
		return "No shape";
	}

	@Override
	public void drawing() {
		for (IShape iShape : shapes) {
			iShape.drawing();
		}
	}

	public void add(IShape shape) {
		shapes.add(shape);
	}

	public void remove(IShape shape) {
		shapes.remove(shape);
	}

}
