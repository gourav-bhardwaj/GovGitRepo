package com.structure.bridge;

public class PanasonicTv implements ITv {

	private boolean isTvOn = false;
	private int volume = 10;
	
	@Override
	public void on() {
		isTvOn = true;
		System.out.println("Panasonic tv ON!!");
	}

	@Override
	public void off() {
		isTvOn = false;
		System.out.println("Panasonic tv OFF!!");
	}

	@Override
	public void switchChannel(int channel) {
		if (isTvOn) {
			System.out.println("Panasonic tv switch on :: "+channel);
		}
	}

	@Override
	public void increaseVolume() {
		if (isTvOn) {
			volume++;
			System.out.println("Panasonic tv volume (+) :: "+volume);
		}
	}

	@Override
	public void decreaseVolume() {
		if (isTvOn) {
			volume--;
			System.out.println("Panasonic tv volume (-) :: "+volume);
		}
	}

	@Override
	public void mute(boolean val) {
		if (isTvOn) {
			System.out.println("Panasonic tv "+(val?"mute":"unmute"));
		}
	}

}
