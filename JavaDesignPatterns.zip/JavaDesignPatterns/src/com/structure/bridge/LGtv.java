package com.structure.bridge;

public class LGtv implements ITv {
	
	private boolean isTvOn = false;
	private int volume = 20;

	@Override
	public void on() {
		isTvOn = true;
		System.out.println("LG television ON");
	}

	@Override
	public void off() {
		isTvOn = false;
		System.out.println("LG television OFF");
	}

	@Override
	public void switchChannel(int channel) {
		if (isTvOn) {
			System.out.println("LG television switch on channel no :: "+channel);
		}
	}

	@Override
	public void increaseVolume() {
		if (isTvOn) {
			volume++;
			System.out.println("LG volume (+) :: "+volume);
		}
	}

	@Override
	public void decreaseVolume() {
		if (isTvOn) {
			volume--;
			System.out.println("LG volume (-) :: "+volume);
		}
	}

	@Override
	public void mute(boolean val) {
		if (isTvOn) {
			System.out.println(val?"LG tv mute" : "LG tv unmute");
		}
	}

}
