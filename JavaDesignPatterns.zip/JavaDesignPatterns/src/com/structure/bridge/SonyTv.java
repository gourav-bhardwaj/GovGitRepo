package com.structure.bridge;

public class SonyTv implements ITv {

	private boolean isTvOn = false;
	private int volume = 30;
	
	@Override
	public void on() {
		isTvOn = true;
		System.out.println("Sony Tv ON");
	}

	@Override
	public void off() {
		isTvOn = false;
		System.out.println("Sony Tv OFF");
	}

	@Override
	public void switchChannel(int channel) {
		if (isTvOn) {
			System.out.println("Sony Tv switch on :: "+channel);
		}
	}

	@Override
	public void increaseVolume() {
		if (isTvOn) {
			volume++;
			System.out.println("Sony Tv volume (+) :: "+volume);
		}
	}

	@Override
	public void decreaseVolume() {
		if (isTvOn) {
			volume--;
			System.out.println("Sony Tv volume (-) :: "+volume);
		}
	}

	@Override
	public void mute(boolean val) {
		if (isTvOn) {
			System.out.println("Sony tv "+(val?"mute":"unmute"));
		}
	}

}
