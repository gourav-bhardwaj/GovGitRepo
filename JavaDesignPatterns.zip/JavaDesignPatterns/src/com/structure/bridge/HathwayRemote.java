package com.structure.bridge;

public class HathwayRemote extends AbstractRemote {

	public HathwayRemote(ITv tv) {
		super(tv);
		System.out.println(this.getClass().getSimpleName()+" setup with "+tv.getClass().getSimpleName());
	}

	@Override
	public void on() {
		tv.on();
	}

	@Override
	public void off() {
		tv.off();
	}

	@Override
	public void switchChannel(int channel) {
		tv.switchChannel(channel);
	}

	@Override
	public void increaseVolume() {
		tv.increaseVolume();
	}

	@Override
	public void decreaseVolume() {
		tv.decreaseVolume();
	}

	@Override
	public void mute(boolean val) {
		tv.mute(val);
	}
}
