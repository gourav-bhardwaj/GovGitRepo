package com.structure.bridge;

public abstract class AbstractRemote implements ITv {

	protected ITv tv;
	
	public AbstractRemote(ITv tv) {
		this.tv = tv;
	}

}
