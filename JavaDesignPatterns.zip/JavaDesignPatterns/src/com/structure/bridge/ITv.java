package com.structure.bridge;

public interface ITv {
	void on();
	void off();
	void switchChannel(int channel);
	void increaseVolume();
	void decreaseVolume();
	void mute(boolean val);
}
