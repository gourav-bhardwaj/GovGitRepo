package com.structure.facade;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

public class ClassicHotel extends IMenu implements IHotel {

	private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss a");

	public ClassicHotel() {
		FoodItem foodItem1 = new FoodItem("Chiken cofta", FoodType.NON_VEG, 1, 450);
		FoodItem foodItem2 = new FoodItem("Tanduri chiken", FoodType.NON_VEG, 1, 1200);
		FoodItem foodItem3 = new FoodItem("Matter panner", FoodType.VEG, 1, 230);
		FoodItem foodItem4 = new FoodItem("Mali kofta", FoodType.VEG, 1, 780);
		FoodItem foodItem5 = new FoodItem("Palak panner", FoodType.VEG, 1, 840);
		FoodItem foodItem6 = new FoodItem("Kadhai panner", FoodType.VEG, 1, 142);
		this.setFoodItems(Arrays.asList(foodItem1, foodItem2, foodItem3, foodItem4, foodItem5, foodItem6));
	}
	
	@Override
	public LocalTime openingTime() {
		return LocalTime.parse("10:00:00 AM",formatter);
	}

	@Override
	public LocalTime closingTime() {
		return LocalTime.parse("9:45:00 PM",formatter);
	}

	@Override
	public DayOfWeek[] weekDaysToOpen() {
		return DayOfWeek.values();
	}

}
