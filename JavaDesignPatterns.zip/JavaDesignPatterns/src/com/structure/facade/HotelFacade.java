package com.structure.facade;

import java.util.List;
import java.util.stream.Collectors;

public class HotelFacade {

	public static final List<FoodItem> hotelFoodMenu(HotelEnum hotelEnum, FoodType foodType) {
		IMenu foodMenu = null;
		switch (hotelEnum) {
		case SHRI_NATH_HOTEL:
			foodMenu = new ShriNathHotel();
			break;
		case CLASSIC_HOTEL:
			foodMenu = new ClassicHotel();
			break;
		default:
			break;
		}
		return foodMenu.getFoodItems().stream().filter(food -> {
			return food.getFoodType() == foodType;
		}).collect(Collectors.toList());
	}
	
}
