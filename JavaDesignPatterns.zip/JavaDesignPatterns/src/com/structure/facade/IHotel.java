package com.structure.facade;

import java.time.DayOfWeek;
import java.time.LocalTime;

public interface IHotel {
	
    LocalTime openingTime();
    
    LocalTime closingTime();
    
    DayOfWeek[] weekDaysToOpen();
    
}
