package com.structure.facade;

public enum FoodType {
	VEG, NON_VEG;
}
