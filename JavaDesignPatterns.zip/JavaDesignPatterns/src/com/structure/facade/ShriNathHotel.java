package com.structure.facade;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

public class ShriNathHotel extends IMenu implements IHotel {
	
	private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
	
	public ShriNathHotel() {
		FoodItem foodItem1 = new FoodItem("Rosted chiken", FoodType.NON_VEG, 1, 230);
		FoodItem foodItem2 = new FoodItem("Tanduri chiken", FoodType.NON_VEG, 1, 770);
		FoodItem foodItem3 = new FoodItem("Matter panner", FoodType.VEG, 1, 870);
		FoodItem foodItem4 = new FoodItem("Palak panner", FoodType.VEG, 1, 148);
		FoodItem foodItem5 = new FoodItem("Kadhai panner", FoodType.VEG, 1, 540);
		this.setFoodItems(Arrays.asList(foodItem1, foodItem2, foodItem3, foodItem4, foodItem5));
	}

	@Override
	public LocalTime openingTime() {
		return LocalTime.parse("10:00:00",formatter);
	}

	@Override
	public LocalTime closingTime() {
		return LocalTime.parse("18:45:00",formatter);
	}

	@Override
	public DayOfWeek[] weekDaysToOpen() {
		return DayOfWeek.values();
	}
	
}
