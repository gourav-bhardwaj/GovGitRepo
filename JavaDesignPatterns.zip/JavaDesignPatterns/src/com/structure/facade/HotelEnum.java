package com.structure.facade;

public enum HotelEnum {
	
	SHRI_NATH_HOTEL, CLASSIC_HOTEL;

}
