package com.structure.facade;

public class FoodItem {
	
	String itemName;
	FoodType foodType;
	int quantity;
	int price;
	
	public FoodItem(String itemName, FoodType foodType, int quantity, int price) {
		super();
		this.itemName = itemName;
		this.foodType = foodType;
		this.quantity = quantity;
		this.price = price;
	}

	public String getItemName() {
		return itemName;
	}

	public FoodType getFoodType() {
		return foodType;
	}

	public int getQuantity() {
		return quantity;
	}

	public int getPrice() {
		return price;
	}

}
