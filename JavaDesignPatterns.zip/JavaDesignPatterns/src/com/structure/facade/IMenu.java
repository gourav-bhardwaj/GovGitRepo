package com.structure.facade;

import java.util.List;

public abstract class IMenu {

	protected List<FoodItem> foodItems;
	
	public List<FoodItem> getFoodItems() {
		return foodItems;
	}

	public void setFoodItems(List<FoodItem> foodItems) {
		this.foodItems = foodItems;
	}

}
