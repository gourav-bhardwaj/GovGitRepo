package com;

import java.util.Arrays;
import java.util.List;

import com.structure.bridge.AbstractRemote;
import com.structure.bridge.DishTvRemote;
import com.structure.bridge.ITv;
import com.structure.bridge.LGtv;
import com.structure.bridge.PanasonicTv;
import com.structure.bridge.SonyTv;
import com.structure.bridge.TataSkyRemote;
import com.structure.composite.Circle;
import com.structure.composite.Composite;
import com.structure.composite.Rectangle;
import com.structure.composite.Square;
import com.structure.facade.ClassicHotel;
import com.structure.facade.FoodItem;
import com.structure.facade.FoodType;
import com.structure.facade.HotelEnum;
import com.structure.facade.HotelFacade;
import com.structure.facade.ShriNathHotel;
import com.structure.proxy.Employee;
import com.structure.proxy.EmployeeData;
import com.structure.proxy.Gender;

public class Test {
	
	public static void main(String[] args) {
		
		//TODO: This is the example of Singleton with Multi-threading
		/*Runnable run1 = () -> {
			SingletonEnum obj;
			obj = SingletonEnum.INSTANCE;
			obj.display();
		};
		
		Runnable run2 = () -> {
			SingletonEnum obj;
			obj = SingletonEnum.INSTANCE;
			obj.display();
		};
		
		Thread t1 = new Thread(run1);
		Thread t2 = new Thread(run2);
		
		t1.start();
		t2.start();*/
		
		//TODO: This is the example of Singleton with Serializable
		//Singleton obj = Singleton.getInstance();
		/*SingletonEnum obj1 = null;
		System.out.println("Singleton class instance is created by OOS");
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("E:/singleclazz.obj"));){
			oos.writeObject(SingletonEnum.INSTANCE);
			oos.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Singleton class instance is readed by OIS");
		try (ObjectInputStream ios = new ObjectInputStream(new FileInputStream("E:/singleclazz.obj"))){
			obj1 = (SingletonEnum) ios.readObject();
			System.out.println("Both singleton are same :: "+(SingletonEnum.INSTANCE == obj1));
			obj1.display();
		} catch (Exception e) {
		   e.printStackTrace();
		}*/
		
		//TODO: This is the example of Singleton with Reflection
		/*SingletonEnum obj1 = null;
		try {
			
			Constructor<SingletonEnum> constructor = SingletonEnum.class.getDeclaredConstructor();
			constructor.setAccessible(true);
			obj1 = (SingletonEnum) constructor.newInstance();
			System.out.println("Both singleton instance are same :: "+(SingletonEnum.INSTANCE == obj1));
			obj1.display();
		}
		catch (Exception e) {
			e.printStackTrace();
		}*/
		
		//TODO: This is the example of Singleton with Cloneable.
		/*try {
			Singleton obj = Singleton.getInstance();
			Singleton obj1 = (Singleton) obj.clone();
			System.out.println(obj == obj1);
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		/*User user = new User.UserBuilder(101).gender(Gender.Female).userName("Monika singhal").build();
		System.out.println(user);*/
		
		/*IIndSocket indo = new IndSocket();
		IEuroSocket euro = new EuroSocket();
		
		System.out.println(indo);
		System.out.println(euro);
		
		IEuroSocket adapter = new EuroIndoAdapter(indo);
		
		System.out.println(adapter);*/
		
       //FileDataSource source = new FileDataSource();
       //EncodeFileDataSource ds = new EncodeFileDataSource(source);
       //ds.readData().forEach(System.out::println);
//       ds.writeData("i m gourav kumar and i m doing many works :->.");
//       ds.writeData("Hii my name is anil nayak....");
		
		/*Circle circle = new Circle();
		Square square = new Square();
		Rectangle rectangle = new Rectangle();
		Composite composite = new Composite();
		composite.add(circle);
		composite.add(square);
		composite.add(rectangle);
		composite.drawing();
		System.out.println("===================================================");
		composite.remove(square);
		composite.drawing();*/
		
		/*ITv iTv = new LGtv();
		
		AbstractRemote remote = new DishTvRemote(iTv);
		
		remote.on();
		remote.switchChannel(101);
		remote.decreaseVolume();
		remote.off();
		remote.decreaseVolume();*/
		
		//==========================================================================
		
		/*List<FoodItem> foods = HotelFacade.hotelFoodMenu(HotelEnum.SHRI_NATH_HOTEL, FoodType.VEG);
		foods.forEach(food -> {
			System.out.println(food.getItemName()+" :: "+food.getQuantity()+" :: "+food.getPrice()+" :: "+food.getFoodType().name());
		});*/
		
		Employee emp = new Employee(101, "Amit gupta", Gender.Male, 34000);
		Employee emp1 = new Employee(102, "Smita bhardwaj", Gender.Female, 14000);
		Employee emp2 = new Employee(103, "Anamil khan", Gender.Male, 15200);
		Employee emp3 = new Employee(104, "Umesh sighal", Gender.Male, 18700);
		
		EmployeeData empData = new EmployeeData();
		empData.add(emp);
		empData.add(emp1);
		empData.add(emp2);
		empData.add(emp3);
		
		Employee result = empData.get(102);
		System.out.println(result.getId());
		/*System.out.println(result.getName());
		System.out.println(result.getGender());
		System.out.println(result.getSalary());*/
		
		
	}

}
