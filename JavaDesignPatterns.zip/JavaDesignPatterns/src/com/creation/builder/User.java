package com.creation.builder;

public class User {
	
	private int userId;
	private String userName;
	private Gender gender;
	
	public User(int userId) {
		this.userId = userId;
	}
	
	public int getUserId() {
		return userId;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public static class UserBuilder {
		
		private User user;

		public UserBuilder(int userId){
			user = new User(userId);
		}
		
		public UserBuilder userName(String userName) {
			user.setUserName(userName);
			return this;
		}
		
		public UserBuilder gender(Gender gender) {
			user.setGender(gender);
			return this;
		}
		
		public User build() {
			return user;
		}
		
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", gender=" + gender + "]";
	}
	
}
