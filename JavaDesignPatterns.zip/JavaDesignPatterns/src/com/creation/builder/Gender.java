package com.creation.builder;

public enum Gender {
	Male, Female;
}
