package com.creation.singleton;

public class MyClass implements Cloneable {

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
}
