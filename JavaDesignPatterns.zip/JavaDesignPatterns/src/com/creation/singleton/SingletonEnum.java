package com.creation.singleton;

public enum SingletonEnum {
	INSTANCE;
	
	private SingletonEnum() {
		System.out.println("SingletonEnum instance created only once");
	}
	
	public void display() {
		System.out.println("Singleton object invoke display!! in :: "+Thread.currentThread().getName());
	}
}
