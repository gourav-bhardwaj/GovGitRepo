package com.creation.singleton;

import java.io.Serializable;

public class Singleton extends MyClass implements Serializable {
	
	//private static Singleton instance = null;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4646988571651599361L;

	private Singleton() {
		super();
		System.out.println("Singleton instance is created once!! in :: "+Thread.currentThread().getName());
	}
	
	private static class InnerClass {
		private static final Singleton INSTANCE = new Singleton();
		static {
			System.out.println("Inner class loaded into memory!!!");
		}
	}
	
	public static final Singleton getInstance() {
		/*if (Objects.isNull(instance)) {
			synchronized (Singleton.class) {
				if (Objects.isNull(instance)) {
					instance = new Singleton();
				}
			}
		}
		return instance;*/
		return InnerClass.INSTANCE;
	}
	
	public void display() {
		System.out.println("Singleton object invoke display!! in :: "+Thread.currentThread().getName());
	}
	
	
	protected Object readResolve() {
		return InnerClass.INSTANCE;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		return InnerClass.INSTANCE;
	}
}
