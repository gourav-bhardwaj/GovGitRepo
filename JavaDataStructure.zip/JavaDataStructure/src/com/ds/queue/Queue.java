package com.ds.queue;

import java.util.function.Consumer;

public class Queue {
	
	private int maxQueueSize;
	private Object[] array;
	private int rear = -1;
	private int front;
	
	public Queue(int maxQueueSize) {
		this.maxQueueSize = maxQueueSize;
	}
	
	public void enQueue(Object element) {
		try {
			if (array == null) {
				array = new Object[maxQueueSize];
			}
			rear++;
			array[rear] = element;
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void deQueue(Consumer<Object> consumer) {
		int i = front;
		while(i <= rear) {
			consumer.accept(array[i]);
			i++;
		}
	}
	
	public void removeFront() {
		int i = front;
		while(i <= rear) {
			if (array[i] == null) {
				break;
			}
			array[i] = array[i+1];
			i++;
		}
		rear--;
	}
	
	public void removeRear() {
		if (rear >= front) {
			array[rear] = null;
			rear--;
		}
	}

	public int getRear() {
		return rear;
	}

	public int getFront() {
		return front;
	}
	
}
