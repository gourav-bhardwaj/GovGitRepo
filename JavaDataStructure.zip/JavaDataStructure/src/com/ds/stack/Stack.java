package com.ds.stack;

public class Stack {

	private int max;
	private Object[] array;
	private int top = -1;
	
	public Stack(int max) {
		this.max = max;
	}
	
	public void push(Object element) {
		try {
			if (array == null) {
				array = new Object[max];
			}
			top++;
			array[top] = element;
		} catch (ArrayIndexOutOfBoundsException e) {
			throw new StackOverflowError("Stack size "+max+", elements try to add "+(top+1));
		}
	}
	
	public Object peek() {
		if (array != null && top >= 0) {
			return array[top];
		}
		return null;
	}
	
	public void pop() {
		if (array != null && top >= 0) {
			array[top] = null;
			top--;
		}
	}
	
	public int getTop() {
		return top;
	}
	
}
