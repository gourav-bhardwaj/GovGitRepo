package com.ds.linkedlist.doubly;

import java.util.function.Consumer;

public class DoublyLinkedList<T> implements LinkedList<T> {
	
	private Node<T> head;
	private Node<T> tail;
	private int count = 0;

	@Override
	public void addFirst(T obj) {
		if (head == null) {
			head = tail = new Node<>(obj, null, null);
		} else {
			Node<T> node = new Node<>(obj, head, null);
			head.setPrevious(node);
			head = node;
		}
		count++;
	}

	@Override
	public void addLast(T obj) {
		if (tail == null) {
			head = tail = new Node<>(obj, null, null);
		} else {
			Node<T> node = new Node<>(obj, null, tail);
			tail.setNext(node);
			tail = node;
		}
		count++;
	}

	@Override
	public void removeFirst() {
		if(head != null) {
			head = head.getNext();
			count--;
		}
	}

	@Override
	public void removeLast() {
		if(tail != null) {
			Node<T> temp = tail.getPrevious();
			temp.setNext(null);
			tail = temp;
			count--;
		}
	}

	@Override
	public Node<T> head() {
		return head;
	}

	@Override
	public Node<T> tail() {
		return tail;
	}

	@Override
	public Node<T> searchNode(T obj) {
		Node<T> temp = head;
		while(temp != null) {
			if (temp.getData().equals(obj)) {
				return temp;
			}
			temp = temp.getNext();
		}
		return null;
	}

	@Override
	public int size() {
		return count;
	}
	
	@Override
	public void forward(Consumer<T> consumer) {
		Node<T> temp = head;
		while(temp != null) {
			consumer.accept(temp.getData());
			temp = temp.getNext();
		}
	}
	
	@Override
	public void backward(Consumer<T> consumer) {
		Node<T> temp = tail;
		while(temp != null) {
			consumer.accept(temp.getData());
			temp = temp.getPrevious();
		}
	}

}
