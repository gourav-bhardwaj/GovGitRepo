package com.ds.linkedlist.doubly;

import java.util.function.Consumer;

public interface LinkedList<T> {
		void addFirst(T obj);
		void addLast(T obj);
		void removeFirst();
		void removeLast();
		Node<T> head();
		Node<T> tail();
		Node<T> searchNode(T obj);
		int size();
		void forward(Consumer<T> consumer);
		void backward(Consumer<T> consumer);
}
