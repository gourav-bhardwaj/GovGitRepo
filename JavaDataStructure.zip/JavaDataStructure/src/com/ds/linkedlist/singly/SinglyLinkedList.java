package com.ds.linkedlist.singly;

import java.util.function.Consumer;

public class SinglyLinkedList<T> implements LinkedList<T> {

	private Node<T> head = null;
	private Node<T> tail = null;
	private int count = 0;
	
	@Override
	public void addFirst(T obj) {
		if(head == null){
			head = tail = new Node<>(obj, null);
		} else {
			head = new Node<>(obj, head);
		}
		count++;
	}
	
	@Override 
	public void addLast(T obj) {
		if(tail == null){
			head = tail = new Node<>(obj, null);
		} else {
			Node<T> node = new Node<>(obj, null);
			tail.setNext(node);
			tail = node;
		}
		count++;
	}
	
	@Override 
	public void removeFirst() {
		if (head != null) {
			head = head.getNext();
			count--;
		}
	}
	
	@Override 
	public void removeLast() {
		if (tail != null) {
			if (head.getNext() == null) {
				head = tail = null;
			} else {
				Node<T> temp = head;
				while(temp.getNext() != tail) {
					temp = temp.getNext();
				}
				temp.setNext(null);
				tail = temp;
			}
			count--;
		}
	}
	
	@Override
	public Node<T> searchNode(T obj) {
		Node<T> node = head;
		while(node != null) {
			if(node.getData().equals(obj)) {
				return node;
			}
			node = node.getNext();
		}
		return null;
	}
	
	@Override
	public int size() {
		return count;
	}
	
	@Override
	public Node<T> head() {
		return head;
	}

	@Override
	public Node<T> tail() {
		return tail;
	}

	@Override
	public String toString() {
		return "SinglyLinkedList [head=" + head + ", tail=" + tail + ", size=" + count + "]";
	}

	@Override
	public void clear() {
		head = tail = null;
		count = 0;
	}
	
	@Override
	public void forEach(Consumer<T> consumer) {
		Node<T> temp = head;
		while(temp != null) {
			consumer.accept(temp.getData());
			temp = temp.getNext();
		}
	}

}
