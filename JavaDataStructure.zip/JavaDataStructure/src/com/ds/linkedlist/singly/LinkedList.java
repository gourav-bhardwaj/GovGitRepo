package com.ds.linkedlist.singly;

import java.util.function.Consumer;

public interface LinkedList<T> {
		void addFirst(T obj);
		void addLast(T obj);
		void removeFirst();
		void removeLast();
		Node<T> head();
		Node<T> tail();
		Node<T> searchNode(T obj);
		int size();
		void clear();
		void forEach(Consumer<T> consumer);
}
