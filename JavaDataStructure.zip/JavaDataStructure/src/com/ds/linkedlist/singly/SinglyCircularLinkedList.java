package com.ds.linkedlist.singly;

import java.util.function.Consumer;

public class SinglyCircularLinkedList<T> implements LinkedList<T> {

	private Node<T> head = null;
	private Node<T> tail = null;
	private int count = 0;
	
	@Override
	public void addFirst(T obj) {
		if(head == null){
			head = tail = new Node<>(obj, null);
			tail.setNext(head);
		} else {
			head = new Node<>(obj, head);
			tail.setNext(head);
		}
		count++;
	}
	
	@Override 
	public void addLast(T obj) {
		if(tail == null){
			head = tail = new Node<>(obj, null);
			tail.setNext(head);
		} else {
			Node<T> node = new Node<>(obj, head);
			tail.setNext(node);
			tail = node;
		}
		count++;
	}
	
	@Override 
	public void removeFirst() {
		if (head != null) {
			Node<T> temp = head.getNext();
			tail.setNext(temp);
			head = temp;
			count--;
		}
	}
	
	@Override 
	public void removeLast() {
		if (tail != null) {
			if (head == tail) {
				head = tail = null;
			} else {
				Node<T> temp = head;
				while(temp.getNext() != tail) {
					temp = temp.getNext();
				}
				temp.setNext(head);
				tail = temp;
			}
			count--;
		}
	}
	
	@Override
	public Node<T> searchNode(T obj) {
		Node<T> temp = head;
		if (obj != null && temp != null) {
			do {
				if (temp.getData().equals(obj)) {
					return temp;
				}
				temp = temp.getNext();
			} while(temp != head);
		}
		return null;
	}
	
	@Override
	public int size() {
		return count;
	}
	
	@Override
	public Node<T> head() {
		return head;
	}

	@Override
	public Node<T> tail() {
		return tail;
	}

	@Override
	public String toString() {
		return "SinglyLinkedList [head=" + head + ", tail=" + tail + ", size=" + count + "]";
	}

	@Override
	public void clear() {
		head = tail = null;
		count = 0;
	}
	
	@Override
	public void forEach(Consumer<T> consumer) {
		Node<T> temp = head;
		do {
			consumer.accept(temp.getData());
			temp = temp.getNext();
		} while(temp != head);
	}

}
