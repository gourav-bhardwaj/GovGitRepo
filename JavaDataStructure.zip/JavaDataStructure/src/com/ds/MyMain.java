package com.ds;

import com.ds.linkedlist.doubly.DoublyCircularLinkedList;
import com.ds.linkedlist.doubly.LinkedList;
import com.ds.linkedlist.doubly.Node;
import com.ds.queue.Queue;
import com.ds.stack.Stack;

public class MyMain {

	public static void main(String[] args) {

//**************SINGLY LINKED LIST****************************************
		
//		SinglyLinkedList<Integer> list = new SinglyLinkedList<>();
//		list.addFirst(145);
//		list.addLast(17);
//		list.addFirst(24);
//		list.addLast(88);
//		list.addFirst(12);
//		list.addLast(55);
//		list.addFirst(33);
//		list.addLast(74);
		
//		Node<Integer> node = list.head();
//		while(node != null) {
//			System.out.println(node.getData());
//			node = node.getNext();
//		}
		
		//Java - 8 based forEach()
//		list.forEach(data -> {
//			System.out.println(data);
//		});
		
//		Node<Integer> node = list.searchNode(88);
//		System.out.println(node);
		
//		list.removeFirst();
//		list.removeLast();
//		list.forEach(System.out::println);
		
//**************DOUBLY LINKED LIST****************************************
		
//		DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
//		list.addFirst(145);
//		list.addLast(17);
//		list.addFirst(24);
//		list.addLast(88);
//		list.addFirst(12);
//		list.addLast(55);
//		list.addFirst(33);
//		list.addLast(74);
		
		/*Node<Integer> node = list.head();
		while(node != null) {
			System.out.println(node.getData());
			node = node.getNext();
		}*/
		
		//Java - 8 forward/backward
//		list.forward(System.out::println);
//		System.out.println("----------------------------");
//		list.backward(System.out::println);
		
		/*Node<Integer> node = list.searchNode(55);
		System.out.println(node);*/
		
//		list.removeFirst();
//		list.removeLast();
//		list.forward(System.out::println);
		
//**********************CIRCULAR SINGLY LINKED LIST********************************************

//		LinkedList<Integer> list = new SinglyCircularLinkedList<>();
//		list.addFirst(145);
//		list.addLast(17);
//		list.addFirst(24);
//		list.addLast(88);
//		list.addFirst(12);
//		list.addLast(55);
//		list.addFirst(33);
//		list.addLast(74);
//		
//		list.forEach(System.out::println);
		
//		list.removeFirst();
//		list.removeLast();
//		list.removeLast();
//		System.out.println(list.size());
//		list.forEach(System.out::println);
	
//		Node<Integer> node = list.searchNode(145);
//		System.out.println(node);
		
		
//**********************CIRCULAR DOUBLY LINKED LIST********************************************		
//		LinkedList<Integer> list = new DoublyCircularLinkedList<>();
//		list.addFirst(145);
//		list.addLast(17);
//		list.addFirst(24);
//		list.addLast(88);
//		list.addFirst(12);
//		list.addLast(55);
//		list.addFirst(33);
//		list.addLast(74);
		
//		list.forward(System.out::println);
//		System.out.println("-------------------");
//		list.backward(System.out::println);
		
//		list.removeFirst();
//		list.removeLast();
//		System.out.println(list.size());
//		list.forward(System.out::println);
		
//		Node<Integer> node = list.searchNode(145);
//		System.out.println(node);
		
//**********************STACK********************************************
	
		/*Stack stack = new Stack(10);
		stack.push(145);
		stack.push(17);
		stack.push(24);
		stack.push(88);
		stack.push(12);
		stack.push(55);
		stack.push(33);
		stack.push(74);
		stack.push(345);
		stack.push(45);
		stack.push(90);
		
		System.out.println(stack.getTop());
		System.out.println("------------");
		System.out.println(stack.peek());
		System.out.println("------------");
		stack.pop();
		stack.pop();
		stack.push(345);
		System.out.println(stack.peek());*/

//**********************QUEUE********************************************
		
		/*Queue queue = new Queue(100);
		queue.enQueue(145);
		queue.enQueue(17);
		queue.enQueue(24);
		queue.enQueue(88);
		queue.enQueue(12);
		queue.enQueue(55);
		queue.enQueue(33);
		queue.enQueue(74);
		queue.enQueue(345);
		queue.enQueue(45);
		queue.enQueue(90);*/
		
//		queue.removeFront();
//		queue.removeRear();
//		queue.deQueue(ele -> {
//			System.out.println(ele);
//		});
		
	
	}

}
